const {app, BrowserWindow,ipcMain, shell} = require('electron')
const child_process = require('child_process');
const path = require('path')

function createWindow() {
    const win = new BrowserWindow({
        width: 1000,
        height: 800,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false,
            enableRemoteModule: true,
            defaultFontFamily: {
                standard: 'Helvetica'
            }

        }
    })
    win.webContents.openDevTools()

    win.loadFile('static/html/index.html')
}


function run_shell(event) {
    var child_9000 = child_process.spawn('python', ['server.py', '9000'])
    var child_9001 = child_process.spawn('python', ['server.py', '9001'])
    var child_9002 = child_process.spawn('python', ['server.py', '9002'])
    var child_9003 = child_process.spawn('python', ['server.py', '9003'])
    var child_9004 = child_process.spawn('python', ['server.py', '9004'])

    child_9000.stdout.setEncoding('utf8')
    child_9001.stdout.setEncoding('utf8')
    child_9002.stdout.setEncoding('utf8')
    child_9003.stdout.setEncoding('utf8')
    child_9004.stdout.setEncoding('utf8')

    child_9000.stdout.on('data', (data) => {
        console.log(data)
        event.sender.send('listening', {msg: `${data}`, msg_type: 'normal', port: '9000'})

    })
    child_9001.stdout.on('data', (data) => {
        console.log(data)
        event.sender.send('listening', {msg: `${data}`, msg_type: 'normal', port: '9001'})

    })
    child_9002.stdout.on('data', (data) => {
        console.log(data)
        event.sender.send('listening', {msg: `${data}`, msg_type: 'normal', port: '9002'})

    })
    child_9003.stdout.on('data', (data) => {
        console.log(data)
        event.sender.send('listening', {msg: `${data}`, msg_type: 'normal', port: '9003'})

    })
    child_9004.stdout.on('data', (data) => {
        console.log(data)
        event.sender.send('listening', {msg: `${data}`, msg_type: 'normal', port: '9004'})

    })


}

app.whenReady().then(() => {
    createWindow()

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createWindow()
        }
    })
})

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit()
    }
})

ipcMain.on('start_server', (event => {
    run_shell(event)
}))

ipcMain.on('reload', (event =>{
    child_process.exec('taskkill /IM "python.exe" /F')

    run_shell(event)
}))
